<?php
$conn = mysqli_connect("localhost", "root", "", "royal_educity");
// $conn = mysqli_connect("localhost", "royalso2", "o61mNxB4w(YJ.1", "royalso2_educity");

<?php
$paystackSecretKey = "sk_test_e3bb322135d48ff5c41900329e9aceade2dc7511";
$paystackPublicKey = "pk_test_6b38f7df0cc64d91bf7d90e3d56980b0e2024e4b";